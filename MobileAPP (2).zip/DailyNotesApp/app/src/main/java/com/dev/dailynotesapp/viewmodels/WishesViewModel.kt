package com.dev.dailynotesapp.viewmodels

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.dev.dailynotesapp.repositories.WishRepository
import com.dev.dailynotesapp.tables.Wish
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class WishesViewModel @Inject constructor(private val wishRepository: WishRepository) :
    ViewModel() {

    val wishesList: LiveData<List<Wish>> = wishRepository.getWishes()

    fun addWish(wish: Wish) {
        wishRepository.addWish(wish = wish)
    }

}