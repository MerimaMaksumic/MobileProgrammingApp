package com.dev.dailynotesapp.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.dev.dailynotesapp.data_interfaces.BooksDao
import com.dev.dailynotesapp.data_interfaces.WishesDao
import com.dev.dailynotesapp.tables.Book
import com.dev.dailynotesapp.tables.Wish

@Database(entities = [Book::class, Wish::class], version = 1, exportSchema = false)
abstract class MyRoomDatabase : RoomDatabase() {

    abstract fun bookDao(): BooksDao
    abstract fun wishDao(): WishesDao

    companion object {

        @Volatile
        var INSTANCE: MyRoomDatabase? = null

        fun getInstance(context: Context): MyRoomDatabase {
            var instance = INSTANCE
            synchronized(this) {
                if (instance == null) {
                    instance = Room.databaseBuilder(
                        context.applicationContext,
                        MyRoomDatabase::class.java,
                        "details_database"
                    ).fallbackToDestructiveMigration().build()
                    INSTANCE = instance
                }
                return INSTANCE!!
            }
        }

    }
}