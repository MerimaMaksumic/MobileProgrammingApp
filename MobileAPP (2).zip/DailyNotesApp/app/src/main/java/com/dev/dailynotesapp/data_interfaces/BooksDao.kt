package com.dev.dailynotesapp.data_interfaces

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import com.dev.dailynotesapp.tables.Book

@Dao
interface BooksDao {

    @Insert
    suspend fun addBook(book: Book)

    @Query("SELECT * FROM book")
    fun getAllBooks(): LiveData<List<Book>>

    @Delete
    suspend fun deleteBook(book: Book)

}