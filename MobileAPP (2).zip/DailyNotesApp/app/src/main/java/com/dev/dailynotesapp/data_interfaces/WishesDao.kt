package com.dev.dailynotesapp.data_interfaces

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import com.dev.dailynotesapp.tables.Wish

@Dao
interface WishesDao {

    @Insert
    suspend fun addWish(wish: Wish)

    @Query("SELECT * FROM wish")
    fun getAllWishes(): LiveData<List<Wish>>

    @Delete
    suspend fun deleteWish(wish: Wish)


}