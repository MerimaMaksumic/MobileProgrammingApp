package com.dev.dailynotesapp.fragments

import android.content.Context
import android.content.Intent
import androidx.activity.viewModels
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Card
import androidx.compose.material.IconButton
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.constraintlayout.compose.ConstraintLayout
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.dev.dailynotesapp.AddBookActivity
import com.dev.dailynotesapp.BookDetailsActivity
import com.dev.dailynotesapp.MainActivity
import com.dev.dailynotesapp.R
import com.dev.dailynotesapp.tables.Book
import com.dev.dailynotesapp.viewmodels.BooksViewModel
import java.util.Collections.copy

@Composable
fun BooksFragment(lifecycle: Lifecycle, context: Context) {

    val bookList = remember { mutableStateListOf<Book>() }

    val staticContext = context as MainActivity

    val viewModel: BooksViewModel by staticContext.viewModels()

    val eventObserver = remember(lifecycle) {
        LifecycleEventObserver { source, event ->
            if (event == Lifecycle.Event.ON_CREATE) {
                viewModel.booksList.observe(context) {
                    //BookRecyclerViewColumn(books = it)
                    bookList.clear()
                    bookList.addAll(it)
                }
            }
        }
    }

    DisposableEffect(lifecycle) {
        lifecycle.addObserver(eventObserver)
        onDispose {
            lifecycle.removeObserver(eventObserver)
        }
    }

    BookRecyclerViewColumn(books = bookList, context)

}


@Composable
fun BookRecyclerViewColumn(books: List<Book>, c: Context) {

    ConstraintLayout(modifier = Modifier.fillMaxSize()) {

        val (addBtn) = createRefs()

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.White)
        )
        Image(
            painter = painterResource(id = R.mipmap.ok2_foreground), // Replace with your desired image resource
            contentDescription = "Background Image",
            modifier = Modifier
                .fillMaxSize()

        )


        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp)
        ) {
            items(books) {
                ItemsCard(item = it, c)
            }
        }

        IconButton(
            onClick = {
                val i = Intent(c, AddBookActivity::class.java)
                c.startActivity(i)
            },
            modifier = Modifier
                .padding(8.dp)
                .constrainAs(addBtn) {
                    top.linkTo(parent.top, margin = 20.dp)
                    end.linkTo(parent.end, margin = 20.dp)
                }
        ) {
            Image(
                painter = painterResource(id = R.drawable.plus_icon),
                contentDescription = "Plus Icon",
                modifier = Modifier.size(48.dp),
            )
        }

    }
}


@Composable
fun ItemsCard(item: Book, cardContext: Context) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable {
                val i = Intent(cardContext, BookDetailsActivity::class.java)
                i.putExtra("title", item.title)
                i.putExtra("author", item.author)
                i.putExtra("description", item.description)
                cardContext.startActivity(i)
            }
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .background(
                shape = RoundedCornerShape(10.dp),
                color = Color.Transparent
            )

    ) {
        ConstraintLayout(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            val (title, author, description, spacer1) = createRefs()

            Text(
                text = item.title,
                minLines = 1,
                modifier = Modifier.constrainAs(title) {
                    top.linkTo(parent.top, 7.dp)
                    start.linkTo(parent.start, margin = 15.dp)
                },
                style = TextStyle(
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            )

            Text(
                text = item.author,
                minLines = 1,
                modifier = Modifier.constrainAs(author) {
                    top.linkTo(title.bottom, 7.dp)
                    start.linkTo(parent.start, margin = 15.dp)
                },
                style = TextStyle(
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            )

            Text(
                text = item.description,
                maxLines = 3,
                modifier = Modifier.constrainAs(description) {
                    top.linkTo(author.top, 7.dp)
                    start.linkTo(parent.start, margin = 15.dp)
                    bottom.linkTo(parent.bottom)
                },
                style = TextStyle(
                    fontSize = 14.sp,
                    color = Color.Gray
                )
            )

            Spacer(modifier = Modifier
                .size(10.dp)
                .constrainAs(spacer1) {
                    top.linkTo(description.bottom)
                    start.linkTo(parent.start)
                    end.linkTo(parent.end)
                })
        }
    }
}
