package com.dev.dailynotesapp

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.constraintlayout.compose.ConstraintLayout
import com.dev.dailynotesapp.ui.theme.DailyNotesAppTheme

class WishDetailsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DailyNotesAppTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colors.background
                ) {
                    val title = intent.getStringExtra("title").toString()
                    val description = intent.getStringExtra("description").toString()

                    ShowWishDetails(t =title, des =description)
                }
            }
        }
    }


    @Composable
    fun ShowWishDetails(t: String, des: String) {
        ConstraintLayout(modifier = Modifier.fillMaxSize()) {

            val (titleLabel, titleTv, descriptionLabel, descriptionTv) = createRefs()

            Text(
                text = "Title",
                style = TextStyle(
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                ),
                modifier = Modifier.constrainAs(titleLabel) {
                    top.linkTo(parent.top, margin = 30.dp)
                    start.linkTo(parent.start, margin = 20.dp)
                }
            )

            Text(
                text = t,
                style = TextStyle(
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                ),
                modifier = Modifier.constrainAs(titleTv) {
                    top.linkTo(titleLabel.top)
                    start.linkTo(titleLabel.end, margin = 6.dp)
                    bottom.linkTo(titleLabel.bottom)
                }
            )


            Text(
                text = "Description:",
                style = TextStyle(
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                ),
                modifier = Modifier.constrainAs(descriptionLabel) {
                    top.linkTo(titleLabel.bottom, margin = 10.dp)
                    start.linkTo(parent.start, margin = 20.dp)
                }
            )

            Text(
                text = des,
                style = TextStyle(
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                ),
                modifier = Modifier.constrainAs(descriptionTv) {
                    top.linkTo(descriptionLabel.top)
                    start.linkTo(descriptionLabel.end, margin = 6.dp)
                    bottom.linkTo(descriptionLabel.bottom)
                }
            )


        }

    }
}
