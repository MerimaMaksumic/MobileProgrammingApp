package com.dev.dailynotesapp.fragments

import android.content.Context
import android.content.Intent
import androidx.activity.viewModels
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Card
import androidx.compose.material.IconButton
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.constraintlayout.compose.ConstraintLayout
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.dev.dailynotesapp.*
import com.dev.dailynotesapp.R
import com.dev.dailynotesapp.tables.Book
import com.dev.dailynotesapp.tables.Wish
import com.dev.dailynotesapp.viewmodels.BooksViewModel
import com.dev.dailynotesapp.viewmodels.WishesViewModel

@Composable
fun WishFragment(lifecycle: Lifecycle, context: Context) {

    val wishList = remember { mutableStateListOf<Wish>() }

    val staticContext = context as MainActivity

    val viewModel: WishesViewModel by staticContext.viewModels()

    val eventObserver = remember(lifecycle) {
        LifecycleEventObserver { source, event ->
            if (event == Lifecycle.Event.ON_CREATE) {
                viewModel.wishesList.observe(context) {
                    //BookRecyclerViewColumn(books = it)
                    wishList.clear()
                    wishList.addAll(it)
                }
            }
        }
    }

    DisposableEffect(lifecycle) {
        lifecycle.addObserver(eventObserver)
        onDispose {
            lifecycle.removeObserver(eventObserver)
        }
    }

    WishRecyclerViewColumn(wishes = wishList, context)

}


@Composable
fun WishRecyclerViewColumn(wishes: List<Wish>, c: Context) {

    ConstraintLayout(modifier = Modifier.fillMaxSize()) {

        val (addBtn) = createRefs()

        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.White)
        )
        Image(
            painter = painterResource(id = R.mipmap.ok2_foreground), // Replace with your desired image resource
            contentDescription = "Background Image",
            modifier = Modifier
                .fillMaxSize()

        )

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(8.dp)
        ) {
            items(wishes) {
                ItemsCard(item = it, c)
            }
        }

        IconButton(
            onClick = {
                val i = Intent(c, AddWishActivity::class.java)
                c.startActivity(i)
            },
            modifier = Modifier
                .padding(8.dp)
                .constrainAs(addBtn) {
                    top.linkTo(parent.top, margin = 20.dp)
                    end.linkTo(parent.end, margin = 20.dp)
                }
        ) {
            Image(
                painter = painterResource(id = R.drawable.plus_icon),
                contentDescription = "Plus Icon",
                modifier = Modifier.size(48.dp),
            )
        }

    }
}

@Composable
fun ItemsCard(item: Wish, cardContext: Context) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable {
                val i = Intent(cardContext, WishDetailsActivity::class.java)
                i.putExtra("title", item.title)
                i.putExtra("description", item.description)
                cardContext.startActivity(i)
            }
            .padding(horizontal = 8.dp, vertical = 4.dp)
            .background(
                shape = RoundedCornerShape(10.dp),
                color = Color.Black
            )

    ) {
        ConstraintLayout(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black)
        ) {
            val (title, description, spacer1) = createRefs()

            Text(
                text = item.title,
                minLines = 1,
                modifier = Modifier.constrainAs(title) {
                    top.linkTo(parent.top, 7.dp)
                    start.linkTo(parent.start, margin = 15.dp)
                },
                style = TextStyle(
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            )

            Text(
                text = item.description,
                maxLines = 3,
                modifier = Modifier.constrainAs(description) {
                    top.linkTo(title.top, 7.dp)
                    start.linkTo(parent.start, margin = 15.dp)
                    bottom.linkTo(parent.bottom)
                },
                style = TextStyle(
                    fontSize = 14.sp,
                    color = Color.Gray
                )
            )

            Spacer(modifier = Modifier
                .size(10.dp)
                .constrainAs(spacer1) {
                    top.linkTo(description.bottom)
                    start.linkTo(parent.start)
                    end.linkTo(parent.end)
                })
        }
    }
}