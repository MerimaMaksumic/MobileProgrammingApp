package com.dev.dailynotesapp.fragments

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.ui.graphics.vector.ImageVector


sealed class Fragment(val route: String, val label: String, val icon: ImageVector) {
    object bookFragment : Fragment("book", "Books",Icons.Default.MenuBook)
    object wishFragment : Fragment("wish", "WishList", Icons.Default.List)
}
