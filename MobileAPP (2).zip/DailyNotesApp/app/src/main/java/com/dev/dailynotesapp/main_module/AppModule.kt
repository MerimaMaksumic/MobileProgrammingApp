package com.dev.dailynotesapp.main_module

import android.content.Context
import com.dev.dailynotesapp.data_interfaces.BooksDao
import com.dev.dailynotesapp.data_interfaces.WishesDao
import com.dev.dailynotesapp.database.MyRoomDatabase
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton


@Module
@InstallIn(SingletonComponent::class)
class AppModule {

    @Singleton
    @Provides
    fun getDb(@ApplicationContext context: Context): MyRoomDatabase {
        return MyRoomDatabase.getInstance(context)
    }

    @Singleton
    @Provides
    fun bookDao(db: MyRoomDatabase): BooksDao {
        return db.bookDao()
    }

    @Singleton
    @Provides
    fun wishDao(db: MyRoomDatabase): WishesDao {
        return db.wishDao()
    }

}