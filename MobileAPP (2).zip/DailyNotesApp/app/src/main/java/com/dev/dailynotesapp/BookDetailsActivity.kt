package com.dev.dailynotesapp

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.MaterialTheme
import androidx.compose.material.Surface
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.constraintlayout.compose.ConstraintLayout
import com.dev.dailynotesapp.ui.theme.DailyNotesAppTheme

class BookDetailsActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DailyNotesAppTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colors.background
                ) {
                    val title = intent.getStringExtra("title").toString()
                    val author = intent.getStringExtra("author").toString()
                    val description = intent.getStringExtra("description").toString()

                    ShowBookDetails(t = title, a = author, des = description)
                }
            }
        }
    }

    @Composable
    fun ShowBookDetails(t: String, a: String, des: String) {
        ConstraintLayout(modifier = Modifier.fillMaxSize()) {

            val (titleLabel, titleTv, authorLabel, authorTv, descriptionLabel, descriptionTv) = createRefs()

            Text(
                text = "Title:",
                style = TextStyle(
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                ),
                modifier = Modifier.constrainAs(titleLabel) {
                    top.linkTo(parent.top, margin = 30.dp)
                    start.linkTo(parent.start, margin = 20.dp)
                }
            )

            Text(
                text = t,
                style = TextStyle(
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                ),
                modifier = Modifier.constrainAs(titleTv) {
                    top.linkTo(titleLabel.top)
                    start.linkTo(titleLabel.end, margin = 6.dp)
                    bottom.linkTo(titleLabel.bottom)
                }
            )


            Text(
                text = "Author:",
                style = TextStyle(
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                ),
                modifier = Modifier.constrainAs(authorLabel) {
                    top.linkTo(titleLabel.bottom, margin = 10.dp)
                    start.linkTo(parent.start, margin = 20.dp)
                }
            )

            Text(
                text = a,
                style = TextStyle(
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                ),
                modifier = Modifier.constrainAs(authorTv) {
                    top.linkTo(authorLabel.top)
                    start.linkTo(authorLabel.end, margin = 6.dp)
                    bottom.linkTo(authorLabel.bottom)
                }
            )




            Text(
                text = "Description:",
                style = TextStyle(
                    fontWeight = FontWeight.Bold,
                    fontSize = 18.sp
                ),
                modifier = Modifier.constrainAs(descriptionLabel) {
                    top.linkTo(authorLabel.bottom, margin = 10.dp)
                    start.linkTo(parent.start, margin = 20.dp)
                }
            )

            Text(
                text = des,
                style = TextStyle(
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                ),
                modifier = Modifier.constrainAs(descriptionTv) {
                    top.linkTo(descriptionLabel.top)
                    start.linkTo(descriptionLabel.end, margin = 6.dp)
                    bottom.linkTo(descriptionLabel.bottom)
                }
            )


        }

    }
}
