package com.dev.dailynotesapp

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.constraintlayout.compose.ConstraintLayout
import com.dev.dailynotesapp.data_interfaces.BooksDao
import com.dev.dailynotesapp.tables.Book
import com.dev.dailynotesapp.ui.theme.DailyNotesAppTheme
import com.dev.dailynotesapp.ui.theme.Purple200
import com.dev.dailynotesapp.ui.theme.Purple500
import com.dev.dailynotesapp.ui.theme.Purple700
import com.dev.dailynotesapp.viewmodels.BooksViewModel
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class AddBookActivity : ComponentActivity() {
    @Inject
    lateinit var booksDao: BooksDao

    private val booksViewModel: BooksViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DailyNotesAppTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colors.background
                ) {
                    AddBookScreen()
                }
            }
        }
    }


    @Composable
    fun AddBookScreen() {
        var bookTitle by remember { mutableStateOf("") }
        var authorName by remember { mutableStateOf("") }
        var description by remember { mutableStateOf("") }

        ConstraintLayout(
            modifier = Modifier.fillMaxSize()
        ) {

            val guideline = createGuidelineFromTop(0.10f)

            val (title, bookNameTv, authorTv, descriptionTv, addBtn) = createRefs()

            Text(
                text = "Add Book",
                modifier = Modifier.constrainAs(title) {
                    top.linkTo(guideline)
                    start.linkTo(parent.start)
                    end.linkTo(parent.end)
                },
                style = TextStyle(
                    color = Color.Black,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace
                )
            )

            OutlinedTextField(
                value = bookTitle,
                onValueChange = { thisName -> bookTitle = thisName },
                modifier = Modifier
                    .constrainAs(bookNameTv) {
                        top.linkTo(title.bottom, margin = 15.dp)
                        start.linkTo(parent.start)
                        end.linkTo(parent.end)
                    }
                    .fillMaxWidth()
                    .height(60.dp)
                    .padding(start = 30.dp, end = 30.dp),
                shape = RoundedCornerShape(10.dp),
                label = {
                    Text(
                        text = "Book Title",
                        style = TextStyle(
                            fontSize = 16.sp
                        )
                    )
                },
                colors = TextFieldDefaults.outlinedTextFieldColors(
                    focusedBorderColor = Purple700,
                    unfocusedBorderColor = Purple200,
                    textColor = Color.Black,
                    backgroundColor = Color.White
                ),
                singleLine = true,
                textStyle = TextStyle(
                    fontSize = 15.sp
                )
            )


            OutlinedTextField(
                value = authorName,
                onValueChange = { thisEmail -> authorName = thisEmail },
                modifier = Modifier
                    .constrainAs(authorTv) {
                        top.linkTo(bookNameTv.bottom, margin = 10.dp)
                        start.linkTo(parent.start)
                        end.linkTo(parent.end)
                    }
                    .fillMaxWidth()
                    .height(60.dp)
                    .padding(start = 30.dp, end = 30.dp),
                shape = RoundedCornerShape(10.dp),
                label = {
                    Text(
                        text = "Author Name",
                        style = TextStyle(
                            fontSize = 16.sp
                        )
                    )
                },
                singleLine = true,
                colors = TextFieldDefaults.outlinedTextFieldColors(
                    focusedBorderColor = Purple700,
                    unfocusedBorderColor = Purple200,
                    textColor = Color.Black,
                    backgroundColor = Color.White
                ),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Email
                ),
                textStyle = TextStyle(
                    fontSize = 15.sp
                )
            )


            OutlinedTextField(
                value = description,
                onValueChange = { description = it },
                modifier = Modifier
                    .constrainAs(descriptionTv) {
                        top.linkTo(authorTv.bottom, margin = 10.dp)
                        start.linkTo(parent.start)
                        end.linkTo(parent.end)
                    }
                    .fillMaxWidth()
                    .padding(start = 30.dp, end = 30.dp),
                shape = RoundedCornerShape(10.dp),
                label = {
                    Text(
                        text = "Description",
                        style = TextStyle(
                            fontSize = 16.sp
                        )
                    )
                },
                maxLines = 7,
                colors = TextFieldDefaults.outlinedTextFieldColors(
                    focusedBorderColor = Purple700,
                    unfocusedBorderColor = Purple200,
                    textColor = Color.Black,
                    backgroundColor = Color.White
                ),
                keyboardOptions = KeyboardOptions(
                    keyboardType = KeyboardType.Email
                ),
                textStyle = TextStyle(
                    fontSize = 15.sp
                )
            )


            Button(
                onClick = {
                    if (bookTitle.isNotEmpty() &&
                        authorName.isNotEmpty() &&
                        description.isNotEmpty()
                    ) {
                        addBook(Book(0, bookTitle, authorName, description), booksViewModel)
                    } else {
                        Toast.makeText(
                            this@AddBookActivity,
                            "Fill all fields",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                },

                modifier = Modifier
                    .constrainAs(addBtn) {
                        top.linkTo(descriptionTv.bottom, margin = 15.dp)
                        start.linkTo(parent.start)
                        end.linkTo(parent.end)
                    }
                    .height(50.dp)
                    .padding(start = 30.dp, end = 30.dp),
                contentPadding = PaddingValues(),
                shape = RoundedCornerShape(15.dp)
            ) {

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            brush = Brush.horizontalGradient(
                                listOf(Purple700, Purple500, Purple200)
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {

                    Text(
                        text = "Submit Details",
                        style = TextStyle(
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )

                }

            }

        }
    }

    private fun addBook(book: Book, viewModel: BooksViewModel) {
        viewModel.addBook(book)
        Toast.makeText(
            this@AddBookActivity,
            "Book Added Success",
            Toast.LENGTH_SHORT
        ).show()
    }

}

