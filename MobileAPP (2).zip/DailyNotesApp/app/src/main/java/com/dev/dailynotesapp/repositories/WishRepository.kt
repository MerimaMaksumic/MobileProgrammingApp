package com.dev.dailynotesapp.repositories

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.dev.dailynotesapp.data_interfaces.WishesDao
import com.dev.dailynotesapp.tables.Wish
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

class WishRepository @Inject constructor(private val wishesDao: WishesDao) {

    val wishMutableLiveDataList = MutableLiveData<List<Wish>>()
    private val coroutineScope = CoroutineScope(Dispatchers.Main)


    fun addWish(wish: Wish) {
        coroutineScope.launch {
            wishesDao.addWish(wish)
        }
    }

    fun getWishes(): LiveData<List<Wish>> {
        return wishesDao.getAllWishes()
    }

}