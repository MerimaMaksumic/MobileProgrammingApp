package com.dev.dailynotesapp.repositories

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.dev.dailynotesapp.data_interfaces.BooksDao
import com.dev.dailynotesapp.tables.Book
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import javax.inject.Inject

class BookRepository @Inject constructor(private val booksDao: BooksDao) {

    private val coroutineScope = CoroutineScope(Dispatchers.Main)

    fun addBook(book: Book) {
        coroutineScope.launch {
            booksDao.addBook(book)
        }
    }

    fun getBooks(): LiveData<List<Book>> {
        return booksDao.getAllBooks()
    }


}