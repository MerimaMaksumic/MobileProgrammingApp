package com.dev.dailynotesapp.viewmodels

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.dev.dailynotesapp.repositories.BookRepository
import com.dev.dailynotesapp.tables.Book
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class BooksViewModel @Inject constructor(private val bookRepository: BookRepository) : ViewModel() {

    val booksList: LiveData<List<Book>>
        get() = bookRepository.getBooks()

    fun addBook(book: Book) {
        bookRepository.addBook(book = book)
    }
}